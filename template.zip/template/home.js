const outName = document.getElementById("name");
outName.innerHTML= localStorage.getItem("Name");

function openNav() {
document.getElementById("mysidenav").style.width = "150px";
}

function closeNav() {
document.getElementById("mysidenav").style.width = "0";
}
